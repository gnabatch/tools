﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InstaAutoReplyStory.Model
{
  public class ActionModel
  {
    public int Status { get; set; }
    public string Username { get; set; }
    public string Type { get; set; }
    public string Response { get; set; }
  }
}
