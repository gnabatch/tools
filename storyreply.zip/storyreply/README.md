# Instagram Auto Reply Story
Tools for automatically reply your your Followers Instagram Target Stories, including Slides Story, Questions Story, Polls Story.

![Screenshoot](Images/Screenshoot.PNG)

## Features
You can automatically Reply Stories, Reply Questions Stories, Slides Stories, and Polls Stories to your Followers Instagram Target, so you can targeting your audience for your Instagram Account.

## Cross Platform
This software build using .NET Core so you need read this: [Dotnet Core Docs](https://docs.microsoft.com/en-us/dotnet/core/deploying/).<br>
<b>How to run:</b><br>
- For Windows, you need to install [Dotnet Core Runtime](https://dotnet.microsoft.com/download/dotnet-core/current/runtime) and then you can download from latest release files.<br>
- For other Operating System like Linux and MacOs, you need to compile this source code first, and run it.


## License(s)
<b>This Source Code and Software is free for non-commercial use.</b>

## Donations
https://paypal.me/itsfirdy

## Credits
- https://github.com/ramtinak/InstagramApiSharp (Ramtinak)
